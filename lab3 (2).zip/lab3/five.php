<?php
$msg = "";

// Cookie options
$cookie_lifetime = time() + (86400 * 7); // 7 days

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? '';

    if ($action === 'store') {
        $username = $_POST['username'] ?? '';
        $role = $_POST['role'] ?? '';

        // Set cookies
        setcookie("username", $username, $cookie_lifetime);
        setcookie("role", $role, $cookie_lifetime);

        $msg = "Cookies stored successfully.";

    } elseif ($action === 'retrieve') {
        if (isset($_COOKIE['username']) && isset($_COOKIE['role'])) {
            $msg = "Stored Username: " . htmlspecialchars($_COOKIE['username']) . "<br>" .
                   "Stored Role: " . htmlspecialchars($_COOKIE['role']);
        } else {
            $msg = "No cookie data found.";
        }

    } elseif ($action === 'destroy') {
        // Expire cookies by setting their time in the past
        setcookie("username", "", time() - 3600);
        setcookie("role", "", time() - 3600);

        $msg = "Cookies destroyed successfully.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cookie Example</title>
</head>
<body>
    <h2>Cookie Example</h2>

    <?php if (!empty($msg)): ?>
        <p><strong><?= $msg ?></strong></p>
    <?php endif; ?>

    <form method="post" action="">
        <label>Enter Username:</label><br>
        <input type="text" name="username"><br><br>

        <label>Enter Role:</label><br>
        <input type="text" name="role"><br><br>

        <button type="submit" name="action" value="store">Store Cookies</button>
        <button type="submit" name="action" value="retrieve">Retrieve Cookies</button>
        <button type="submit" name="action" value="destroy">Destroy Cookies</button>
    </form>
</body>
</html>
