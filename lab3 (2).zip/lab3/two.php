<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$user = "root";
$pass = "";
$db   = "registrations";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);  // Plain text password
    $phone    = trim($_POST['phone']);
    $gender   = $_POST['gender'];
    $faculty  = $_POST['faculty'];

    if (empty($name) || empty($email) || empty($password) || empty($phone) || empty($gender) || empty($faculty)) {
        $msg = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "Invalid email format.";
    } elseif (!preg_match("/^[0-9]{10,15}$/", $phone)) {
        $msg = "Invalid phone number.";
    } else {
        // Store plain text password (not secure)
        $stmt = $conn->prepare("INSERT INTO registrations (name, email, password, phone, gender, faculty) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $email, $password, $phone, $gender, $faculty);

        if ($stmt->execute()) {
            $msg = "Registration successful!";
        } else {
            $msg = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
</head>
<body>
    <h2>User Registration</h2>
    <form method="post">
        Name:<br>
        <input type="text" name="name" required><br><br>

        Email:<br>
        <input type="email" name="email" required><br><br>

        Password:<br>
        <input type="password" name="password" required><br><br>

        Phone:<br>
        <input type="text" name="phone" required><br><br>

        Gender:<br>
        <select name="gender" required>
            <option value="">--Select--</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
        </select><br><br>

        Faculty:<br>
        <input type="text" name="faculty" required><br><br>

        <input type="submit" value="Register">
    </form>

    <?php if ($msg): ?>
        <p><strong><?php echo $msg; ?></strong></p>
    <?php endif; ?>
</body>
</html>
<!--
1. Go to XAMPP. Start APACHE and MYSQL.
2. Go to localhost/phpmyadmin/
3. Click <new> in left side
4. Go to that newly created database name.
//-----------------------------------------------------------------------------------------------//
5. Put a -> NAME = "databs" <- in the table area and after creating table, Go to sql in top part.
<sql_code>
CREATE TABLE registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    faculty VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
</sql_code>
    -->