<?php
$conn = new mysqli("localhost", "root", "", "project");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$id = $_GET['id'] ?? 0;
$id = intval($id);
$error = $success = "";

// Handle update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $publisher = $_POST['publisher'];
    $author = $_POST['author'];
    $edition = $_POST['edition'];
    $no_of_page = intval($_POST['no_of_page']);
    $price = floatval($_POST['price']);
    $publish_date = $_POST['publish_date'];
    $isbn = $_POST['isbn'];

    $stmt = $conn->prepare("UPDATE books SET title=?, publisher=?, author=?, edition=?, no_of_page=?, price=?, publish_date=?, isbn=? WHERE id=?");
    $stmt->bind_param("ssssidssi", $title, $publisher, $author, $edition, $no_of_page, $price, $publish_date, $isbn, $id);

    if ($stmt->execute()) {
        $success = "Book updated successfully.";
    } else {
        $error = "Error updating book: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch existing data
$stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();
$stmt->close();
$conn->close();

if (!$book) {
    die("Book not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Book</title>
</head>
<body>
<h2>Edit Book</h2>
<?php if ($error) echo "<p style='color:red;'>$error</p>"; ?>
<?php if ($success) echo "<p style='color:green;'>$success</p>"; ?>

<form method="post">
    Title: <input type="text" name="title" value="<?= htmlspecialchars($book['title']) ?>" required><br><br>
    Publisher: <input type="text" name="publisher" value="<?= htmlspecialchars($book['publisher']) ?>" required><br><br>
    Author: <input type="text" name="author" value="<?= htmlspecialchars($book['author']) ?>" required><br><br>
    Edition: <input type="text" name="edition" value="<?= htmlspecialchars($book['edition']) ?>"><br><br>
    Pages: <input type="number" name="no_of_page" value="<?= $book['no_of_page'] ?>"><br><br>
    Price: <input type="text" name="price" value="<?= $book['price'] ?>"><br><br>
    Publish Date: <input type="date" name="publish_date" value="<?= $book['publish_date'] ?>"><br><br>
    ISBN: <input type="text" name="isbn" value="<?= htmlspecialchars($book['isbn']) ?>" required><br><br>
    <input type="submit" value="Update Book">
</form>

<a href="eight.php">Back to Book List</a>
</body>
</html>
