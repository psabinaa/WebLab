<?php
// Start session if you want to track login state
// session_start();

$loginError = '';
$welcomeMessage = '';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Database connection (adjust as needed)
    $conn = new mysqli("localhost", "root", "", "registrations");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Using prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM registrations WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $email, $password);  // If using password hashing, change this logic
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $welcomeMessage = "Welcome, " . htmlspecialchars($user['name']) . "!";
        // Optionally store session data:
        // $_SESSION['user'] = $user;
    } else {
        $loginError = "Invalid email or password.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - Question 3</title>
</head>
<body>
    <h2>User Login</h2>

    <form method="post" action="qsn3.php">
        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Login</button>
    </form>

    <?php if ($loginError): ?>
        <p style="color:red;"><?= $loginError ?></p>
    <?php endif; ?>

    <?php if ($welcomeMessage): ?>
        <h3 style="color:green;"><?= $welcomeMessage ?></h3>
    <?php endif; ?>
</body>
</html>
