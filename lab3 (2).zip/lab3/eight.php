<?php
$conn = new mysqli("localhost", "root", "", "project");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM books ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Books</title>
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; }
        th { background-color: #f4f4f4; }
    </style>
</head>
<body>
    <h2>Stored Books</h2>
    <a href="seven.php">Add New Book</a><br><br>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Publisher</th>
                <th>Author</th>
                <th>Edition</th>
                <th>Pages</th>
                <th>Price</th>
                <th>Publish Date</th>
                <th>ISBN</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['title']) ?></td>
                    <td><?= htmlspecialchars($row['publisher']) ?></td>
                    <td><?= htmlspecialchars($row['author']) ?></td>
                    <td><?= htmlspecialchars($row['edition']) ?></td>
                    <td><?= $row['no_of_page'] ?></td>
                    <td><?= $row['price'] ?></td>
                    <td><?= $row['publish_date'] ?></td>
                    <td><?= htmlspecialchars($row['isbn']) ?></td>
                    <td>
                        <a href="nine.php?id=<?= $row['id'] ?>">Edit</a> |
                        <a href="ten.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this book?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No books found.</p>
    <?php endif; ?>

    <?php $conn->close(); ?>
    <style>
        a:visited{color:blue;}
        </style>
</body>
</html>
