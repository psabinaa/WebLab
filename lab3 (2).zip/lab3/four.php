<?php
session_start();

$msg = "";

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'store') {
        $_SESSION['username'] = $_POST['username'] ?? '';
        $_SESSION['role'] = $_POST['role'] ?? '';
        $msg = "Session stored successfully.";
    } elseif ($action === 'retrieve') {
        if (isset($_SESSION['username']) && isset($_SESSION['role'])) {
            $msg = "Stored Username: " . htmlspecialchars($_SESSION['username']) . "<br>" .
                   "Stored Role: " . htmlspecialchars($_SESSION['role']);
        } else {
            $msg = "No session data found.";
        }
    } elseif ($action === 'destroy') {
        session_unset();
        session_destroy();
        $msg = "Session destroyed successfully.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Session Example</title>
</head>
<body>
    <h2>Session Example</h2>

    <?php if (!empty($msg)): ?>
        <p><strong><?= $msg ?></strong></p>
    <?php endif; ?>

    <form method="post" action="">
        <label>Enter Username:</label><br>
        <input type="text" name="username"><br><br>

        <label>Enter Role:</label><br>
        <input type="text" name="role"><br><br>

        <button type="submit" name="action" value="store">Store Session</button>
        <button type="submit" name="action" value="retrieve">Retrieve Session</button>
        <button type="submit" name="action" value="destroy">Destroy Session</button>
    </form>
</body>
</html>
